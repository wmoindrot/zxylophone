Paddy Moindrot's ZX81 music programs
=====================================

These are ZX81 tape files (.p). Load them into a ZX81 emulator such as
EightyOne (Windows), or onto a real ZX81 with a .p file loader.
All need 16K of memory. Each one starts by itself once loaded.

ZXYLOPHONE_fixed.p     ZXYLOPHONE with the three fixes (FAST mode, port 254,
                       a tidy SHIFT+RUBOUT stop). Enter RUN to play.
COMPOSER_finished.p    COMPOSER, finished in 2026: R records a tune,
                       P plays it back, S saves it with the program.
ZXYLOPHONE_as_found.p  ZXYLOPHONE exactly as it came off the cassette.
TUNES_1985.p           TUNES from Sinclair Programs, March 1985, with
                       "When the Saints Go Marching In" in line 2.

Sound: these make sound the way the real ZX81 did, through the TV
speaker (the sync signal). Choose an emulator option for that kind of
sound to hear them.
